// Paste your Firebase web app config here (Firebase Console > Project settings > Your apps).
// This config is NOT secret. Security comes from firestore.rules.
export const firebaseConfig = {
  apiKey: "PASTE_HERE",
  authDomain: "PASTE_HERE",
  projectId: "PASTE_HERE",
  storageBucket: "PASTE_HERE",
  messagingSenderId: "PASTE_HERE",
  appId: "PASTE_HERE"
};
