import {initializeApp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {getAuth,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,signOut,sendPasswordResetEmail} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {getFirestore,doc,getDoc,setDoc,updateDoc,addDoc,collection,query,where,orderBy,limit,onSnapshot,runTransaction,serverTimestamp,arrayUnion,arrayRemove,deleteField} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {firebaseConfig} from "./firebase-config.js";

const $=id=>document.getElementById(id);
const app=initializeApp(firebaseConfig), auth=getAuth(app), db=getFirestore(app);
let me=null, mode="login", registering=false, unsubChats=null, unsubMsgs=null, cache={}, cur=null, tt;

const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const show=id=>["auth","main","chat","grp"].forEach(s=>$(s).hidden=s!==id);
const busy=b=>$("loading").style.display=b?"flex":"none";
const toast=m=>{const t=$("toast");t.textContent=m;t.style.opacity=1;clearTimeout(tt);tt=setTimeout(()=>t.style.opacity=0,3500)};
const av=u=>u.group?'<div class="av">👥</div>':u.photoURL?`<img class="av" src="${esc(u.photoURL)}">`:`<div class="av">${esc((u.displayName||"?")[0].toUpperCase())}</div>`;
const fmt=t=>{if(!t)return"";const d=t.toDate(),n=new Date();return d.toDateString()===n.toDateString()?d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):d.toLocaleDateString([],{day:"numeric",month:"short"})};
const errMsg=e=>({
  "auth/invalid-email":"That email address is not valid.",
  "auth/invalid-credential":"Wrong email or password.",
  "auth/user-not-found":"Wrong email or password.",
  "auth/wrong-password":"Wrong email or password.",
  "auth/email-already-in-use":"This email is already registered. Try logging in.",
  "auth/weak-password":"Password must be at least 6 characters.",
  "auth/network-request-failed":"No internet connection. Check your network and try again.",
  "auth/too-many-requests":"Too many attempts. Please wait a few minutes.",
  "permission-denied":"You don't have permission to do that.",
  "unavailable":"Can't reach the server. Check your internet."
}[e.code]||e.message||"Something went wrong. Try again.");

// ---------- push notifications ----------
const WORKER="https://hafizzone-push.skarif0187.workers.dev";
const Push=window.Capacitor?.Plugins?.PushNotifications;
let pushOn=false;
async function setupPush(){
  if(!Push)return;
  try{
    let p=await Push.checkPermissions();
    if(p.receive!=="granted")p=await Push.requestPermissions();
    if(p.receive!=="granted")return;
    if(!pushOn){pushOn=true;Push.addListener("registration",t=>{if(me)setDoc(doc(db,"tokens",me.uid),{token:t.value},{merge:true}).catch(()=>{})})}
    await Push.createChannel({id:"messages",name:"Messages",description:"New message alerts",sound:"hafiz_tone.wav",importance:5,visibility:1,vibration:true});
    await Push.register();
  }catch(e){}
}

// network banner
const net=()=>$("net").hidden=navigator.onLine;
addEventListener("online",net);addEventListener("offline",net);net();

// ---------- auth ----------
function setMode(m){mode=m;const r=m==="register";$("a-forgot").hidden=r;$("a-name").hidden=$("a-id").hidden=!r;$("a-go").textContent=r?"Create account":"Log in";$("a-switch").textContent=r?"Have an account? Log in":"New here? Create account"}
$("a-switch").onclick=()=>setMode(mode==="login"?"register":"login");
$("a-go").onclick=async()=>{
  const email=$("a-email").value.trim(), pass=$("a-pass").value;
  if(!/^\S+@\S+\.\S+$/.test(email))return toast("Enter a valid email.");
  if(pass.length<6)return toast("Password must be at least 6 characters.");
  if(!navigator.onLine)return toast("No internet connection.");
  const name=$("a-name").value.trim(), id=$("a-id").value.trim().toLowerCase().replace(/^@/,"");
  if(mode==="register"){
    if(!name)return toast("Enter your display name.");
    if(!/^[a-z0-9_]{3,20}$/.test(id))return toast("ID must be 3–20 characters: a-z, 0-9 or _");
  }
  busy(true);
  try{
    if(mode==="login")await signInWithEmailAndPassword(auth,email,pass);
    else{
      registering=true;
      const cred=await createUserWithEmailAndPassword(auth,email,pass);
      try{
        await runTransaction(db,async t=>{
          const h=doc(db,"handles",id);
          if((await t.get(h)).exists())throw {message:"This ID is already taken. Choose another."};
          t.set(h,{uid:cred.user.uid});
          t.set(doc(db,"users",cred.user.uid),{displayName:name,hafizId:id,photoURL:""});
        });
      }catch(e){await cred.user.delete().catch(()=>{});throw e}
      registering=false;
      await onUser(cred.user);
    }
  }catch(e){registering=false;toast(errMsg(e))}
  busy(false);
};
onAuthStateChanged(auth,u=>{if(registering)return;u?onUser(u):onOut()});

async function onUser(u){
  busy(true);
  try{
    const s=await getDoc(doc(db,"users",u.uid));
    if(!s.exists())throw {message:"Profile not found. Please create the account again."};
    me={uid:u.uid,...s.data()};cache[u.uid]=me;
    renderMe();show("main");tab("chats");listenChats();beat();loadMuted();setupPush();
  }catch(e){toast(errMsg(e));await signOut(auth).catch(()=>{});show("auth")}
  busy(false);
}
function onOut(){unsubChats?.();unsubMsgs?.();unsubChat?.();unsubChat=null;me=null;cache={};cur=null;busy(false);show("auth")}

// ---------- tabs ----------
let curTab="chats";
function tab(t){curTab=t;["chats","find","me"].forEach(n=>{$("tab-"+n).hidden=n!==t;$("nav-"+n).classList.toggle("on",n===t)});$("top").textContent={chats:"Chats",find:"Find friends",me:"Profile"}[t]}
["chats","find","me"].forEach(n=>$("nav-"+n).onclick=()=>tab(n));

async function getUser(uid){
  if(!cache[uid]){const s=await getDoc(doc(db,"users",uid));cache[uid]=s.exists()?{uid,...s.data()}:{uid,displayName:"Unknown user"}}
  return cache[uid];
}

// ---------- recent chats ----------
function listenChats(){
  unsubChats?.();
  $("chat-list").innerHTML='<p class="empty">Loading…</p>';
  unsubChats=onSnapshot(query(collection(db,"chats"),where("members","array-contains",me.uid)),async snap=>{
    try{
      const rows=await Promise.all(snap.docs.map(async d=>{const c=d.data({serverTimestamps:"estimate"});return {c,id:d.id,f:c.isGroup?{uid:d.id,displayName:c.name,group:true}:await getUser(c.members.find(x=>x!==me.uid))}}));
      rows.sort((a,b)=>(b.c.lastTime?.toMillis()||0)-(a.c.lastTime?.toMillis()||0));chatRows=rows;
      $("chat-list").innerHTML=rows.length?rows.map((r,i)=>`<div class="item" data-i="${i}">${av(r.f)}<div class="grow"><b>${esc(r.f.displayName)}</b><small>${esc(r.c.lastMessage)}</small></div><small>${fmt(r.c.lastTime)}</small></div>`).join(""):'<p class="empty">No chats yet.<br>Open “Find” and search a friend’s ID.</p>';
      $("chat-list").querySelectorAll(".item").forEach(el=>el.onclick=()=>{const r=rows[el.dataset.i];openChat(r.f,r.c.isGroup?r.id:null)});
    }catch(e){toast(errMsg(e))}
  },e=>toast(errMsg(e)));
}

// ---------- find friends ----------
$("f-go").onclick=async()=>{
  const id=$("f-id").value.trim().toLowerCase().replace(/^@/,""), out=$("f-result");
  if(!/^[a-z0-9_]{3,20}$/.test(id))return toast("Enter a valid HafizZone ID.");
  if(!navigator.onLine)return toast("No internet connection.");
  busy(true);out.innerHTML="";
  try{
    const h=await getDoc(doc(db,"handles",id));
    if(!h.exists())out.innerHTML='<p class="empty">No user found with this ID.</p>';
    else{
      const u=await getUser(h.data().uid);
      if(u.uid===me.uid)out.innerHTML='<p class="empty">That’s your own ID.</p>';
      else{
        out.innerHTML=`<div class="item">${av(u)}<div class="grow"><b>${esc(u.displayName)}</b><small>@${esc(u.hafizId)}${u.bio?" · "+esc(u.bio):""}</small></div><button>Message</button></div>`;
        out.querySelector("button").onclick=()=>openChat(u);
      }
    }
  }catch(e){toast(errMsg(e))}
  busy(false);
};

// ---------- private chat ----------
function openChat(f,gid){
  cur={f,id:gid||[me.uid,f.uid].sort().join("_"),group:!!gid};cur.members=gid?null:[me.uid,f.uid];seen={};
  $("c-add").hidden=true;
  if(gid)getDoc(doc(db,"chats",gid)).then(s=>{if(cur&&cur.id===gid){cur.owner=s.data().owner;cur.members=s.data().members;$("c-add").hidden=cur.owner!==me.uid}}).catch(()=>{});
  $("c-name").textContent=f.displayName;$("c-av").innerHTML=av(f);$("msgs").innerHTML="";MS={};clearBar();closeFind();watchPresence();bellUI();$("c-game").hidden=cur.group;$("c-info").hidden=!cur.group;
  show("chat");unsubMsgs?.();unsubChat?.();unsubChat=null;watchChat();
  unsubMsgs=onSnapshot(query(collection(db,"chats",cur.id,"messages"),orderBy("ts"),limit(300)),snap=>{
    const box=$("msgs");
    box.innerHTML=snap.docs.map(d=>{const m=d.data({serverTimestamps:"estimate"}),mine=m.from===me.uid;m.id=d.id;MS[d.id]=m;
      return `<div class="b ${mine?"me":"fr"}${m.type==="sticker"?" stkb":m.type==="game"?" gm":""}" data-id="${d.id}" data-ms="${m.ts?m.ts.toMillis():0}">${cur.group&&!mine?`<small class="nm" data-u="${esc(m.from)}"></small>`:""}${m.fwd&&!m.deleted?'<small class="fw">↪ Forwarded</small>':""}${m.reply&&!m.deleted?`<div class="qt"><b>${esc(m.reply.name)}</b>${esc(m.reply.text)}</div>`:""}${body(m)}<small>${fmt(m.ts)}${m.edited&&!m.deleted?" · edited":""}${mine&&d.metadata.hasPendingWrites?" · sending…":""}</small>${rx(m)}</div>`}).join("");
    box.scrollTop=box.scrollHeight;hydrate(box);paintSeen();applySearch();
    const lm=snap.docs[snap.docs.length-1];if(lm&&lm.data().from!==me.uid)markSeen();
  },e=>toast(errMsg(e)));
}
function closeChat(){if(rec)stopRec(false);$("emo").hidden=true;unsubPres?.();unsubPres=null;clearBar();closeFind();player?.pause();unsubMsgs?.();unsubMsgs=null;unsubChat?.();unsubChat=null;cur=null;show("main")}
$("c-back").onclick=closeChat;
async function send(){
  const text=$("c-input").value.trim();
  if(!text||!cur)return;
  if(!navigator.onLine)return toast("No internet. Message not sent.");
  if(editing){
    const id=editing;clearBar();$("c-input").value="";
    try{await updateDoc(doc(db,"chats",cur.id,"messages",id),{text,edited:true})}catch(e){toast("Couldn't edit. "+errMsg(e))}
    return;
  }
  const rp=replyTo;clearBar();$("c-input").value="";
  try{await post(cur,{text,reply:rp})}catch(e){$("c-input").value=text;toast("Message not sent. "+errMsg(e))}
}
$("c-send").onclick=send;
$("c-input").onkeydown=e=>{if(e.key==="Enter")send()};

// ---------- profile ----------
function renderMe(){$("p-av").innerHTML=av(me);$("p-name").value=me.displayName;$("p-id").value=me.hafizId;$("p-bio").value=me.bio||""}
async function saveProfile(p){
  busy(true);
  try{await updateDoc(doc(db,"users",me.uid),p);Object.assign(me,p);renderMe();toast("Saved")}
  catch(e){toast("Not saved. "+errMsg(e))}
  busy(false);
}
$("p-save").onclick=()=>{const n=$("p-name").value.trim();n?saveProfile({displayName:n}):toast("Display name can't be empty.")};
$("p-copy").onclick=()=>navigator.clipboard.writeText(me.hafizId).then(()=>toast("ID copied"),()=>toast("Couldn't copy. Select the ID and copy it manually."));
$("p-out").onclick=()=>signOut(auth);
$("p-file").onchange=e=>{
  const f=e.target.files[0];if(!f)return;
  const img=new Image();
  img.onload=()=>{
    const c=document.createElement("canvas");c.width=c.height=128;
    const s=Math.min(img.width,img.height);
    c.getContext("2d").drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,128,128);
    URL.revokeObjectURL(img.src);
    saveProfile({photoURL:c.toDataURL("image/jpeg",.7)});
  };
  img.onerror=()=>toast("Couldn't read that image.");
  img.src=URL.createObjectURL(f);e.target.value="";
};

// ---------- back button ----------
const CapApp=window.Capacitor?.Plugins?.App;
CapApp?.addListener("backButton",()=>{
  if(!$("sheet").hidden)$("sheet").hidden=true;
  else if(!$("grp").hidden)closeG();
  else if(!$("chat").hidden)closeChat();
  else if(!$("main").hidden&&curTab!=="chats")tab("chats");
  else CapApp.minimizeApp();
});

// ---------- photos and voice messages (stored in Firestore, free) ----------
const media={};let rec=null,chunks=[],t0=0,tick=null,player=null;
const fmtDur=s=>Math.floor((s||0)/60)+":"+String((s||0)%60).padStart(2,"0");
const body=m=>m.deleted?'<i class="dl">🚫 Message deleted</i>':m.type==="sticker"?`<span class="stk">${esc(m.text)}</span>`:m.type==="game"?gameUI(m):m.type==="voice"?`<button class="pl" data-mid="${esc(m.mid)}">▶</button>🎤 ${fmtDur(m.dur)}`:m.type==="image"?`<div class="ph" data-mid="${esc(m.mid)}">📷</div>`:esc(m.text);
const ping=(cid,text)=>auth.currentUser.getIdToken().then(t=>fetch(WORKER,{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+t},body:JSON.stringify({chatId:cid,text})})).catch(()=>{});
async function getMedia(cid,id){
  if(!media[id]){const s=await getDoc(doc(db,"chats",cid,"media",id));media[id]=s.data().data}
  return media[id];
}
const io=new IntersectionObserver(es=>es.forEach(async e=>{
  if(!e.isIntersecting)return;io.unobserve(e.target);
  try{const src=await getMedia(cur.id,e.target.dataset.mid);showImg(e.target,src)}catch(x){}
}));
function showImg(el,src){if(!el.isConnected)return;const i=new Image();i.className="im";i.src=src;el.replaceWith(i)}
function hydrate(box){box.querySelectorAll(".nm").forEach(async el=>{el.textContent=(await getUser(el.dataset.u)).displayName});box.querySelectorAll(".ph").forEach(el=>media[el.dataset.mid]?showImg(el,media[el.dataset.mid]):io.observe(el))}
$("msgs").onclick=async e=>{
  const b=e.target.closest(".pl"),im=e.target.closest(".im");
  if(im)return im.classList.toggle("big");
  if(!b)return;
  try{player?.pause();player=new Audio(await getMedia(cur.id,b.dataset.mid));await player.play()}
  catch(x){toast("Couldn't play this voice message.")}
};
async function sendMedia(kind,data,dur){
  if(!cur)return;
  if(!navigator.onLine)return toast("No internet. Not sent.");
  busy(true);
  try{await post(cur,{type:kind,data,dur})}catch(e){toast("Not sent. "+errMsg(e))}
  busy(false);
}
$("c-img").onchange=e=>{
  const f=e.target.files[0];e.target.value="";if(!f)return;
  const img=new Image();
  img.onload=()=>{
    const k=Math.min(1,900/Math.max(img.width,img.height)),c=document.createElement("canvas");
    c.width=Math.round(img.width*k);c.height=Math.round(img.height*k);
    c.getContext("2d").drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(img.src);
    sendMedia("image",c.toDataURL("image/jpeg",.65),0);
  };
  img.onerror=()=>toast("Couldn't read that image.");
  img.src=URL.createObjectURL(f);
};
async function startRec(){
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)return toast("Voice recording isn't supported on this phone.");
  try{
    const st=await navigator.mediaDevices.getUserMedia({audio:true});
    const mt=MediaRecorder.isTypeSupported("audio/webm;codecs=opus")?"audio/webm;codecs=opus":"";
    rec=new MediaRecorder(st,mt?{mimeType:mt,audioBitsPerSecond:16000}:{audioBitsPerSecond:16000});
    chunks=[];rec.ondataavailable=e=>chunks.push(e.data);rec.start();t0=Date.now();
    $("rec").hidden=false;$("comp").hidden=true;
    tick=setInterval(()=>{const n=Math.floor((Date.now()-t0)/1000);$("rec-t").textContent="● "+fmtDur(n);if(n>=120)stopRec(true)},500);
  }catch(e){rec=null;toast("Microphone permission is needed to record.")}
}
function stopRec(send){
  clearInterval(tick);if(!rec)return;
  const r=rec;rec=null;$("rec").hidden=true;$("comp").hidden=false;
  const dur=Math.round((Date.now()-t0)/1000);
  r.onstop=()=>{
    r.stream.getTracks().forEach(t=>t.stop());
    if(!send||dur<1)return;
    const fr=new FileReader();fr.onload=()=>sendMedia("voice",fr.result,dur);
    fr.readAsDataURL(new Blob(chunks,{type:r.mimeType||"audio/webm"}));
  };
  r.stop();
}
$("c-mic").onclick=startRec;$("rec-x").onclick=()=>stopRec(false);$("rec-ok").onclick=()=>stopRec(true);

// ---------- groups ----------
const meta=(ch,t)=>ch.group?{lastMessage:t,lastTime:serverTimestamp()}:{members:[me.uid,ch.f.uid].sort(),lastMessage:t,lastTime:serverTimestamp()};
let gSel=[],gAddTo=null;
function renderG(){
  $("g-list").innerHTML=gSel.map((u,i)=>`<div class="item">${av(u)}<div class="grow"><b>${esc(u.displayName)}</b><small>@${esc(u.hafizId||"")}</small></div><button class="ib" data-i="${i}">✕</button></div>`).join("")||'<p class="empty">Add friends by their ID.</p>';
  $("g-list").querySelectorAll("button").forEach(b=>b.onclick=()=>{gSel.splice(+b.dataset.i,1);renderG()});
}
function openG(addTo){
  gAddTo=addTo;gSel=[];$("g-name").value="";$("g-id").value="";$("g-name").hidden=!!addTo;
  $("g-title").textContent=addTo?"Add members":"New group";$("g-ok").textContent=addTo?"Add to group":"Create group";
  renderG();show("grp");
}
function closeG(){show(gAddTo&&cur?"chat":"main")}
$("g-new").onclick=()=>openG(null);
$("c-add").onclick=()=>openG(cur.id);
$("g-back").onclick=closeG;
$("g-add").onclick=async()=>{
  const id=$("g-id").value.trim().toLowerCase().replace(/^@/,"");
  if(!/^[a-z0-9_]{3,20}$/.test(id))return toast("Enter a valid HafizZone ID.");
  if(!navigator.onLine)return toast("No internet connection.");
  busy(true);
  try{
    const h=await getDoc(doc(db,"handles",id));
    if(!h.exists())toast("No user found with this ID.");
    else{
      const u=await getUser(h.data().uid);
      if(u.uid===me.uid||gSel.some(x=>x.uid===u.uid)||(gAddTo&&cur?.members?.includes(u.uid)))toast("Already added.");
      else{gSel.push(u);$("g-id").value="";renderG()}
    }
  }catch(e){toast(errMsg(e))}
  busy(false);
};
$("g-ok").onclick=async()=>{
  const name=$("g-name").value.trim();
  if(!gAddTo&&!name)return toast("Enter a group name.");
  if(!gSel.length)return toast("Add at least one friend.");
  if(!navigator.onLine)return toast("No internet connection.");
  busy(true);
  try{
    if(gAddTo){
      await updateDoc(doc(db,"chats",gAddTo),{members:arrayUnion(...gSel.map(u=>u.uid))});
      cur.members=[...new Set([...(cur.members||[]),...gSel.map(u=>u.uid)])];
      toast("Members added");closeG();
    }else{
      const ref=doc(collection(db,"chats"));
      await setDoc(ref,{members:[me.uid,...gSel.map(u=>u.uid)],isGroup:true,name,owner:me.uid,lastMessage:"Group created",lastTime:serverTimestamp()});
      openChat({uid:ref.id,displayName:name,group:true},ref.id);
    }
  }catch(e){toast("Not saved. "+errMsg(e))}
  busy(false);
};

// ---------- seen receipts (profile pictures under messages that were seen) ----------
let unsubChat=null,seen={},paintRun=0,mk=null;
const sa=u=>u.photoURL?`<img class="sa" src="${esc(u.photoURL)}">`:`<span class="sa">${esc((u.displayName||"?")[0].toUpperCase())}</span>`;
function watchChat(){
  if(!cur||unsubChat)return;
  const id=cur.id;
  unsubChat=onSnapshot(doc(db,"chats",id),s=>{
    if(!cur||cur.id!==id)return;
    const d=s.data({serverTimestamps:"estimate"})||{};
    seen=d.seen||{};cur.owner=d.owner;if(cur.group&&d.name){cur.f.displayName=d.name;$("c-name").textContent=d.name}if(d.members)cur.members=d.members;if(cur.group&&d.members)$("c-sub").textContent=d.members.length+" members";
    paintSeen();
  },()=>{unsubChat=null});
}
function markSeen(){
  if(mk||!cur)return;
  mk=setTimeout(()=>{
    mk=null;
    if(!cur||document.visibilityState!=="visible")return;
    setDoc(doc(db,"chats",cur.id),{seen:{[me.uid]:serverTimestamp()}},{merge:true}).catch(()=>{});
  },1200);
}
async function paintSeen(){
  if(!cur)return;
  const run=++paintRun,box=$("msgs");
  const ids=Object.keys(seen).filter(u=>u!==me.uid&&(cur.members||[]).includes(u));
  const users=await Promise.all(ids.map(getUser));
  if(run!==paintRun||!cur)return;
  box.querySelectorAll(".sn").forEach(e=>e.remove());
  const mine=[...box.querySelectorAll(".b.me")],by=new Map();
  ids.forEach((u,i)=>{
    const T=seen[u]?.toMillis?.()||0;let tgt=null;
    for(const el of mine){if(+el.dataset.ms<=T)tgt=el;else break}
    if(tgt){if(!by.has(tgt))by.set(tgt,[]);by.get(tgt).push(users[i])}
  });
  by.forEach((us,el)=>el.insertAdjacentHTML("afterend",`<div class="sn">${us.slice(0,4).map(sa).join("")}${us.length>4?`<span class="sm">+${us.length-4}</span>`:""}</div>`));
}
document.addEventListener("visibilitychange",()=>{if(cur&&document.visibilityState==="visible")markSeen()});
CapApp?.addListener("appStateChange",st=>{if(st.isActive&&cur)markSeen()});

// ---------- more chat features: reply, edit, delete, forward, search, mute, online, bio ----------
let unsubPres=null,MS={},replyTo=null,editing=null,lp=null,lpx=0,lpy=0,muted=new Set(),chatRows=[],fwdMsg=null;
async function post(ch,o){
  const c=doc(db,"chats",ch.id);let label=o.text||"",mid=null;
  if(o.type==="voice"||o.type==="image"){label=o.type==="voice"?"🎤 Voice message":"📷 Photo";mid=(await addDoc(collection(c,"media"),{data:o.data,kind:o.type,from:me.uid})).id;media[mid]=o.data}
  ping(ch.id,label);
  await setDoc(c,meta(ch,label.slice(0,80)),{merge:true});
  if(cur&&cur.id===ch.id)watchChat();
  const msg={from:me.uid,text:label,ts:serverTimestamp()};
  if(o.type==="voice"||o.type==="image"){msg.type=o.type;msg.mid=mid;msg.dur=o.dur||0}else if(o.extra)Object.assign(msg,o.extra);
  if(o.reply)msg.reply=o.reply;
  if(o.fwd)msg.fwd=true;
  await addDoc(collection(c,"messages"),msg);
}
const lbl=m=>m.type==="voice"?"🎤 Voice message":m.type==="image"?"📷 Photo":m.text;
function clearBar(){replyTo=null;editing=null;$("rp").hidden=true}
function bar(t){$("rp-t").textContent=t;$("rp").hidden=false;$("c-input").focus()}
$("rp-x").onclick=()=>{if(editing)$("c-input").value="";clearBar()};
// long press on a message opens the action sheet
const msgsEl=$("msgs");
msgsEl.addEventListener("pointerdown",e=>{
  const b=e.target.closest(".b");if(!b||e.target.closest(".pl"))return;
  lpx=e.clientX;lpy=e.clientY;clearTimeout(lp);lp=setTimeout(()=>openSheet(b.dataset.id),450);
});
msgsEl.addEventListener("pointermove",e=>{if(Math.abs(e.clientX-lpx)+Math.abs(e.clientY-lpy)>12)clearTimeout(lp)});
["pointerup","pointercancel"].forEach(t=>msgsEl.addEventListener(t,()=>clearTimeout(lp)));
msgsEl.addEventListener("contextmenu",e=>e.preventDefault());
function sheet(html){$("sh-body").innerHTML=html;$("sheet").hidden=false}
function openSheet(id){
  const m=MS[id];if(!m||m.deleted||!cur||m.type==="game")return;
  const mine=m.from===me.uid,txt=!m.type,B=(a,t)=>`<button data-a="${a}" data-id="${id}">${t}</button>`;
  sheet(`<div class="rxrow">${RX.map(e=>`<button data-a="rx" data-e="${e}" data-id="${id}">${e}</button>`).join("")}</div>`+B("reply","↩ Reply")+(txt?B("copy","⧉ Copy"):"")+B("fwd","➡ Forward")+(mine&&txt?B("edit","✎ Edit"):"")+(mine?B("del","🗑 Delete"):""));
}
$("sh-x").onclick=()=>{$("sheet").hidden=true};
$("sheet").onclick=async e=>{
  if(e.target.id==="sheet"){$("sheet").hidden=true;return}
  const b=e.target.closest("button[data-a]");if(!b||!cur)return;
  const a=b.dataset.a,m=MS[b.dataset.id];
  if(a==="rx"){$("sheet").hidden=true;react(b.dataset.id,b.dataset.e);return}
  if(a==="g"){$("sheet").hidden=true;await newGame(b.dataset.k);return}
  if(a==="rm"){$("sheet").hidden=true;try{await updateDoc(doc(db,"chats",cur.id),{members:arrayRemove(b.dataset.u)});toast("Removed")}catch(x){toast("Couldn't remove. "+errMsg(x))}return}
  if(a==="rename"){
    $("sheet").hidden=true;const n=(prompt("New group name",cur.f.displayName)||"").trim().slice(0,40);
    if(n&&n!==cur.f.displayName)try{await updateDoc(doc(db,"chats",cur.id),{name:n})}catch(x){toast("Couldn't rename. "+errMsg(x))}
    return;
  }
  if(a==="leave"){
    $("sheet").hidden=true;if(!confirm("Leave this group?"))return;
    const rest=(cur.members||[]).filter(x=>x!==me.uid);
    try{await updateDoc(doc(db,"chats",cur.id),cur.owner===me.uid?{members:arrayRemove(me.uid),owner:rest[0]}:{members:arrayRemove(me.uid)});closeChat();toast("You left the group")}
    catch(x){toast("Couldn't leave. "+errMsg(x))}
    return;
  }
  if(a==="to"){
    const r=chatRows[+b.dataset.i];$("sheet").hidden=true;if(!r||!fwdMsg)return;
    busy(true);
    try{
      const o=(fwdMsg.type==="voice"||fwdMsg.type==="image")?{type:fwdMsg.type,data:await getMedia(cur.id,fwdMsg.mid),dur:fwdMsg.dur,fwd:true}:{text:fwdMsg.text,fwd:true,extra:fwdMsg.type==="sticker"?{type:"sticker"}:undefined};
      await post({id:r.id,group:!!r.c.isGroup,f:r.f},o);toast("Forwarded");
    }catch(x){toast("Not forwarded. "+errMsg(x))}
    busy(false);return;
  }
  if(!m)return;
  if(a==="fwd"){
    fwdMsg=m;
    sheet('<small style="padding:4px 6px">Forward to…</small>'+(chatRows.map((r,i)=>`<button data-a="to" data-i="${i}">${esc(r.f.displayName)}</button>`).join("")||"<small>No chats yet.</small>"));
    return;
  }
  $("sheet").hidden=true;
  if(a==="reply"){
    const nm=m.from===me.uid?"You":(await getUser(m.from)).displayName;
    editing=null;replyTo={name:nm,text:lbl(m).slice(0,60)};bar("↩ "+nm+": "+replyTo.text);
  }else if(a==="copy")navigator.clipboard.writeText(m.text).then(()=>toast("Copied"),()=>toast("Couldn't copy."));
  else if(a==="edit"){editing=b.dataset.id;replyTo=null;$("c-input").value=m.text;bar("✎ Editing message")}
  else if(a==="del"&&confirm("Delete this message for everyone?")){
    try{await updateDoc(doc(db,"chats",cur.id,"messages",b.dataset.id),{deleted:true,text:"Message deleted"})}
    catch(x){toast("Couldn't delete. "+errMsg(x))}
  }
};
// search inside the open chat (looks through the last 300 messages)
function applySearch(){
  const q=$("cs-in").value.trim().toLowerCase();
  msgsEl.querySelectorAll(".b").forEach(b=>b.style.display=!q||b.textContent.toLowerCase().includes(q)?"":"none");
  msgsEl.querySelectorAll(".sn").forEach(x=>x.style.display=q?"none":"");
}
function closeFind(){$("cs").hidden=true;$("cs-in").value="";applySearch()}
$("c-find").onclick=()=>{if($("cs").hidden){$("cs").hidden=false;$("cs-in").focus()}else closeFind()};
$("cs-in").oninput=applySearch;$("cs-x").onclick=closeFind;
// mute notifications per chat (the Worker skips muted chats)
async function loadMuted(){try{const s=await getDoc(doc(db,"tokens",me.uid));muted=new Set(s.data()?.muted||[])}catch(e){}}
function bellUI(){if(cur)$("c-bell").textContent=muted.has(cur.id)?"🔕":"🔔"}
$("c-bell").onclick=async()=>{
  if(!cur)return;const id=cur.id,was=muted.has(id);
  try{await updateDoc(doc(db,"tokens",me.uid),{muted:was?arrayRemove(id):arrayUnion(id)});was?muted.delete(id):muted.add(id);bellUI();toast(was?"Notifications on":"Muted")}
  catch(e){toast("Allow notifications on this phone first, then try again.")}
};
// online status
const ago=ms=>{const m=Math.max(1,Math.floor((Date.now()-ms)/60000));return m<60?m+"m":m<1440?Math.floor(m/60)+"h":Math.floor(m/1440)+"d"};
function beat(){if(me&&document.visibilityState==="visible"&&navigator.onLine)updateDoc(doc(db,"users",me.uid),{lastActive:serverTimestamp()}).catch(()=>{})}
setInterval(beat,120000);
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")beat()});
function watchPresence(){
  unsubPres?.();unsubPres=null;
  if(cur.group){$("c-sub").textContent=cur.members?cur.members.length+" members":"Group";return}
  $("c-sub").textContent="";
  unsubPres=onSnapshot(doc(db,"users",cur.f.uid),s=>{
    const t=s.data()?.lastActive?.toMillis?.();
    $("c-sub").innerHTML=t&&Date.now()-t<180000?'<span class="dot"></span>Online':t?"Last seen "+ago(t)+" ago":"";
  },()=>{});
}
$("c-av").onclick=()=>{if(cur&&!cur.group)toast(cur.f.displayName+" · @"+(cur.f.hafizId||"")+(cur.f.bio?" · "+cur.f.bio:""))};
$("p-bsave").onclick=()=>saveProfile({bio:$("p-bio").value.trim().slice(0,80)});

// ---------- fun pack: reactions, emoji, stickers, games ----------
const RX=["👍","❤️","😂","😮","😢","🙏"];
const EM="😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 😎 🤩 🥳 😏 😒 😞 😔 😟 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😓 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😯 😮 😲 🥱 😴 🤤 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 💪 👋 🤝 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💯 🔥 ✨ 🎉 🎊 🎁 🏆 ⚽ 🎮 🍕 🍔 🍟 🍫 ☕ 🌹 🌞 🌙 ⭐ 🐱 🐶 🦁 🐼 🐸 🙈 👻 💀 🤖".split(" ");
const STK="😂 🥰 😎 🤩 😭 😡 🥳 🤔 🙌 👏 💪 🔥 💯 🎉 ❤️ 💔 👻 🤖 🐱 🐶 🦁 🍕 🍔 🏆 😴 🤯 🥺 🙈".split(" ");
let emoTab="e";
const rx=m=>{
  if(m.deleted||!m.reactions)return "";
  const c={};Object.values(m.reactions).forEach(e=>c[e]=(c[e]||0)+1);
  const k=Object.keys(c);if(!k.length)return "";
  return `<div class="rx">${k.map(e=>`<span class="rc${m.reactions[me.uid]===e?" on":""}" data-r="${e}">${e}${c[e]>1?" "+c[e]:""}</span>`).join("")}</div>`;
};
function react(id,e){
  const m=MS[id];if(!m||!cur)return;
  updateDoc(doc(db,"chats",cur.id,"messages",id),{["reactions."+me.uid]:m.reactions?.[me.uid]===e?deleteField():e}).catch(x=>toast("Couldn't react. "+errMsg(x)));
}
msgsEl.addEventListener("click",e=>{const c=e.target.closest(".rc");if(c)react(c.closest(".b").dataset.id,c.dataset.r)});
function emoDraw(){
  $("et-e").classList.toggle("on",emoTab==="e");$("et-s").classList.toggle("on",emoTab==="s");
  $("eg").className=emoTab==="s"?"st":"";
  $("eg").innerHTML=(emoTab==="s"?STK:EM).map(e=>`<button data-e="${e}">${e}</button>`).join("");
}
$("c-emo").onclick=()=>{$("emo").hidden=!$("emo").hidden;if(!$("emo").hidden)emoDraw()};
$("et-e").onclick=()=>{emoTab="e";emoDraw()};
$("et-s").onclick=()=>{emoTab="s";emoDraw()};
$("eg").onclick=async e=>{
  const b=e.target.closest("button");if(!b||!cur)return;
  if(emoTab==="e"){$("c-input").value+=b.dataset.e;return}
  $("emo").hidden=true;
  if(!navigator.onLine)return toast("No internet. Not sent.");
  try{await post(cur,{text:b.dataset.e,extra:{type:"sticker"}})}catch(x){toast("Not sent. "+errMsg(x))}
};
// games between two people (1-to-1 chats only)
const WINS=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const xoWin=b=>{for(const[a,c,d]of WINS)if(b[a]!=="-"&&b[a]===b[c]&&b[a]===b[d])return b[a];return b.includes("-")?"":"D"};
const RPS={r:"✊",p:"✋",s:"✌️"},BEAT={r:"s",p:"r",s:"p"};
function gameUI(m){
  if(!m.p||!cur)return "";
  const on=cur.f?.displayName||"Friend",me2=m.p.includes(me.uid),opp=m.p.find(x=>x!==me.uid);
  if(m.game==="xo"){
    const turnMe=me2&&m.turn===me.uid&&!m.win,X=m.p[0];
    const cells=[...(m.board||"---------")].map((c,i)=>`<button class="xc" data-g="xo" data-i="${i}" ${c!=="-"||!turnMe?"disabled":""}>${c==="-"?"":c==="X"?"❌":"⭕"}</button>`).join("");
    const st=m.win==="D"?"Draw!":m.win?((m.win==="X")===(me.uid===X)?"🎉 You won!":"😕 "+esc(on)+" won"):turnMe?"Your turn ("+(me.uid===X?"❌":"⭕")+")":"Waiting for "+esc(on)+"…";
    return `<div class="gt">🎮 Tic-Tac-Toe</div><div class="xg">${cells}</div><div class="gs">${st}</div>`+(m.win?`<button class="gb" data-g="again" data-k="xo">↻ Play again</button>`:"");
  }
  const mv=m.mv||{},my=mv[me.uid],th=mv[opp];
  let ui;
  if(!my)ui=`<div class="rg">${Object.keys(RPS).map(k=>`<button class="xc" data-g="rps" data-k="${k}">${RPS[k]}</button>`).join("")}</div><div class="gs">Pick one</div>`;
  else if(!th)ui=`<div class="rg">${RPS[my]} vs ❔</div><div class="gs">Waiting for ${esc(on)}…</div>`;
  else ui=`<div class="rg">${RPS[my]} vs ${RPS[th]}</div><div class="gs">${my===th?"Draw!":BEAT[my]===th?"🎉 You won!":"😕 "+esc(on)+" won"}</div><button class="gb" data-g="again" data-k="rps">↻ Play again</button>`;
  return `<div class="gt">🎮 Rock Paper Scissors</div>`+ui;
}
async function newGame(k){
  if(!cur||cur.group)return;
  if(!navigator.onLine)return toast("No internet. Not sent.");
  const extra=k==="xo"?{type:"game",game:"xo",p:[me.uid,cur.f.uid],board:"---------",turn:me.uid,win:""}:{type:"game",game:"rps",p:[me.uid,cur.f.uid],mv:{}};
  try{await post(cur,{text:k==="xo"?"🎮 Tic-Tac-Toe":"🎮 Rock Paper Scissors",extra})}catch(x){toast("Not sent. "+errMsg(x))}
}
msgsEl.addEventListener("click",async e=>{
  const g=e.target.closest("[data-g]");if(!g||!cur)return;
  const id=g.closest(".b")?.dataset.id,m=MS[id];if(!m)return;
  const ref=doc(db,"chats",cur.id,"messages",id);
  try{
    if(g.dataset.g==="xo"){
      const i=+g.dataset.i;if(m.turn!==me.uid||m.win||m.board[i]!=="-")return;
      const bd=m.board.slice(0,i)+(me.uid===m.p[0]?"X":"O")+m.board.slice(i+1);
      await updateDoc(ref,{board:bd,turn:m.p.find(x=>x!==me.uid),win:xoWin(bd)});
    }else if(g.dataset.g==="rps"){
      if(m.mv?.[me.uid])return;
      await updateDoc(ref,{["mv."+me.uid]:g.dataset.k});
    }else if(g.dataset.g==="again")await newGame(g.dataset.k);
  }catch(x){toast("Couldn't play. "+errMsg(x))}
});
$("c-game").onclick=()=>{if(cur&&!cur.group)sheet('<button data-a="g" data-k="xo">❌⭕ Tic-Tac-Toe</button><button data-a="g" data-k="rps">✊✋✌️ Rock Paper Scissors</button>')};

// ---------- forgot password + group info ----------
$("a-forgot").onclick=async()=>{
  const email=$("a-email").value.trim();
  if(!/^\S+@\S+\.\S+$/.test(email))return toast("Type your email above first, then tap Forgot password.");
  try{await sendPasswordResetEmail(auth,email);toast("Reset link sent. Check your email (and spam).")}
  catch(e){toast(errMsg(e))}
};
$("c-info").onclick=async()=>{
  if(!cur?.group)return;
  const ids=cur.members||[],us=await Promise.all(ids.map(getUser)),own=cur.owner===me.uid;
  sheet(`<small style="padding:4px 6px">${esc(cur.f.displayName)} · ${ids.length} members</small>`
    +us.map(u=>`<div class="mrow">${av(u)}<span class="grow">${esc(u.displayName)}${u.uid===cur.owner?" 👑":""}${u.uid===me.uid?" (you)":""}</span>${own&&u.uid!==me.uid?`<button data-a="rm" data-u="${u.uid}">Remove</button>`:""}</div>`).join("")
    +(own?'<button data-a="rename">✎ Rename group</button>':"")+'<button data-a="leave">🚪 Leave group</button>');
};
