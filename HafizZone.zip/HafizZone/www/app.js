import {initializeApp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {getAuth,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,signOut} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {getFirestore,doc,getDoc,setDoc,updateDoc,addDoc,collection,query,where,orderBy,limit,onSnapshot,runTransaction,serverTimestamp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {firebaseConfig} from "./firebase-config.js";

const $=id=>document.getElementById(id);
const app=initializeApp(firebaseConfig), auth=getAuth(app), db=getFirestore(app);
let me=null, mode="login", registering=false, unsubChats=null, unsubMsgs=null, cache={}, cur=null, tt;

const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const show=id=>["auth","main","chat"].forEach(s=>$(s).hidden=s!==id);
const busy=b=>$("loading").style.display=b?"flex":"none";
const toast=m=>{const t=$("toast");t.textContent=m;t.style.opacity=1;clearTimeout(tt);tt=setTimeout(()=>t.style.opacity=0,3500)};
const av=u=>u.photoURL?`<img class="av" src="${esc(u.photoURL)}">`:`<div class="av">${esc((u.displayName||"?")[0].toUpperCase())}</div>`;
const fmt=t=>{if(!t)return"";const d=t.toDate(),n=new Date();return d.toDateString()===n.toDateString()?d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):d.toLocaleDateString([],{day:"numeric",month:"short"})};
const errMsg=e=>({
  "auth/invalid-email":"That email address is not valid.",
  "auth/invalid-credential":"Wrong email or password.",
  "auth/user-not-found":"Wrong email or password.",
  "auth/wrong-password":"Wrong email or password.",
  "auth/email-already-in-use":"This email is already registered. Try logging in.",
  "auth/weak-password":"Password must be at least 6 characters.",
  "auth/network-request-failed":"No internet connection. Check your network and try again.",
  "auth/too-many-requests":"Too many attempts. Please wait a few minutes.",
  "permission-denied":"You don't have permission to do that.",
  "unavailable":"Can't reach the server. Check your internet."
}[e.code]||e.message||"Something went wrong. Try again.");

// ---------- push notifications ----------
const WORKER="https://hafizzone-push.skarif0187.workers.dev";
const Push=window.Capacitor?.Plugins?.PushNotifications;
let pushOn=false;
async function setupPush(){
  if(!Push)return;
  try{
    let p=await Push.checkPermissions();
    if(p.receive!=="granted")p=await Push.requestPermissions();
    if(p.receive!=="granted")return;
    if(!pushOn){pushOn=true;Push.addListener("registration",t=>{if(me)setDoc(doc(db,"tokens",me.uid),{token:t.value}).catch(()=>{})})}
    await Push.register();
  }catch(e){}
}

// network banner
const net=()=>$("net").hidden=navigator.onLine;
addEventListener("online",net);addEventListener("offline",net);net();

// ---------- auth ----------
function setMode(m){mode=m;const r=m==="register";$("a-name").hidden=$("a-id").hidden=!r;$("a-go").textContent=r?"Create account":"Log in";$("a-switch").textContent=r?"Have an account? Log in":"New here? Create account"}
$("a-switch").onclick=()=>setMode(mode==="login"?"register":"login");
$("a-go").onclick=async()=>{
  const email=$("a-email").value.trim(), pass=$("a-pass").value;
  if(!/^\S+@\S+\.\S+$/.test(email))return toast("Enter a valid email.");
  if(pass.length<6)return toast("Password must be at least 6 characters.");
  if(!navigator.onLine)return toast("No internet connection.");
  const name=$("a-name").value.trim(), id=$("a-id").value.trim().toLowerCase().replace(/^@/,"");
  if(mode==="register"){
    if(!name)return toast("Enter your display name.");
    if(!/^[a-z0-9_]{3,20}$/.test(id))return toast("ID must be 3–20 characters: a-z, 0-9 or _");
  }
  busy(true);
  try{
    if(mode==="login")await signInWithEmailAndPassword(auth,email,pass);
    else{
      registering=true;
      const cred=await createUserWithEmailAndPassword(auth,email,pass);
      try{
        await runTransaction(db,async t=>{
          const h=doc(db,"handles",id);
          if((await t.get(h)).exists())throw {message:"This ID is already taken. Choose another."};
          t.set(h,{uid:cred.user.uid});
          t.set(doc(db,"users",cred.user.uid),{displayName:name,hafizId:id,photoURL:""});
        });
      }catch(e){await cred.user.delete().catch(()=>{});throw e}
      registering=false;
      await onUser(cred.user);
    }
  }catch(e){registering=false;toast(errMsg(e))}
  busy(false);
};
onAuthStateChanged(auth,u=>{if(registering)return;u?onUser(u):onOut()});

async function onUser(u){
  busy(true);
  try{
    const s=await getDoc(doc(db,"users",u.uid));
    if(!s.exists())throw {message:"Profile not found. Please create the account again."};
    me={uid:u.uid,...s.data()};cache[u.uid]=me;
    renderMe();show("main");tab("chats");listenChats();setupPush();
  }catch(e){toast(errMsg(e));await signOut(auth).catch(()=>{});show("auth")}
  busy(false);
}
function onOut(){unsubChats?.();unsubMsgs?.();me=null;cache={};cur=null;busy(false);show("auth")}

// ---------- tabs ----------
function tab(t){["chats","find","me"].forEach(n=>{$("tab-"+n).hidden=n!==t;$("nav-"+n).classList.toggle("on",n===t)});$("top").textContent={chats:"Chats",find:"Find friends",me:"Profile"}[t]}
["chats","find","me"].forEach(n=>$("nav-"+n).onclick=()=>tab(n));

async function getUser(uid){
  if(!cache[uid]){const s=await getDoc(doc(db,"users",uid));cache[uid]=s.exists()?{uid,...s.data()}:{uid,displayName:"Unknown user"}}
  return cache[uid];
}

// ---------- recent chats ----------
function listenChats(){
  unsubChats?.();
  $("chat-list").innerHTML='<p class="empty">Loading…</p>';
  unsubChats=onSnapshot(query(collection(db,"chats"),where("members","array-contains",me.uid)),async snap=>{
    try{
      const rows=await Promise.all(snap.docs.map(async d=>{const c=d.data({serverTimestamps:"estimate"});return {c,f:await getUser(c.members.find(x=>x!==me.uid))}}));
      rows.sort((a,b)=>(b.c.lastTime?.toMillis()||0)-(a.c.lastTime?.toMillis()||0));
      $("chat-list").innerHTML=rows.length?rows.map((r,i)=>`<div class="item" data-i="${i}">${av(r.f)}<div class="grow"><b>${esc(r.f.displayName)}</b><small>${esc(r.c.lastMessage)}</small></div><small>${fmt(r.c.lastTime)}</small></div>`).join(""):'<p class="empty">No chats yet.<br>Open “Find” and search a friend’s ID.</p>';
      $("chat-list").querySelectorAll(".item").forEach(el=>el.onclick=()=>openChat(rows[el.dataset.i].f));
    }catch(e){toast(errMsg(e))}
  },e=>toast(errMsg(e)));
}

// ---------- find friends ----------
$("f-go").onclick=async()=>{
  const id=$("f-id").value.trim().toLowerCase().replace(/^@/,""), out=$("f-result");
  if(!/^[a-z0-9_]{3,20}$/.test(id))return toast("Enter a valid HafizZone ID.");
  if(!navigator.onLine)return toast("No internet connection.");
  busy(true);out.innerHTML="";
  try{
    const h=await getDoc(doc(db,"handles",id));
    if(!h.exists())out.innerHTML='<p class="empty">No user found with this ID.</p>';
    else{
      const u=await getUser(h.data().uid);
      if(u.uid===me.uid)out.innerHTML='<p class="empty">That’s your own ID.</p>';
      else{
        out.innerHTML=`<div class="item">${av(u)}<div class="grow"><b>${esc(u.displayName)}</b><small>@${esc(u.hafizId)}</small></div><button>Message</button></div>`;
        out.querySelector("button").onclick=()=>openChat(u);
      }
    }
  }catch(e){toast(errMsg(e))}
  busy(false);
};

// ---------- private chat ----------
function openChat(f){
  cur={f,id:[me.uid,f.uid].sort().join("_")};
  $("c-name").textContent=f.displayName;$("c-av").innerHTML=av(f);$("msgs").innerHTML="";
  show("chat");unsubMsgs?.();
  unsubMsgs=onSnapshot(query(collection(db,"chats",cur.id,"messages"),orderBy("ts"),limit(300)),snap=>{
    const box=$("msgs");
    box.innerHTML=snap.docs.map(d=>{const m=d.data({serverTimestamps:"estimate"}),mine=m.from===me.uid;
      return `<div class="b ${mine?"me":"fr"}">${esc(m.text)}<small>${fmt(m.ts)}${mine&&d.metadata.hasPendingWrites?" · sending…":""}</small></div>`}).join("");
    box.scrollTop=box.scrollHeight;
  },e=>toast(errMsg(e)));
}
$("c-back").onclick=()=>{unsubMsgs?.();unsubMsgs=null;cur=null;show("main")};
async function send(){
  const text=$("c-input").value.trim();
  if(!text||!cur)return;
  if(!navigator.onLine)return toast("No internet. Message not sent.");
  const ch=cur;
  $("c-input").value="";
  try{
    const c=doc(db,"chats",ch.id);
    await setDoc(c,{members:[me.uid,ch.f.uid].sort(),lastMessage:text.slice(0,80),lastTime:serverTimestamp()},{merge:true});
    await addDoc(collection(c,"messages"),{from:me.uid,text,ts:serverTimestamp()});
    auth.currentUser.getIdToken().then(t=>fetch(WORKER,{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+t},body:JSON.stringify({chatId:ch.id,text})})).catch(()=>{});
  }catch(e){$("c-input").value=text;toast("Message not sent. "+errMsg(e))}
}
$("c-send").onclick=send;
$("c-input").onkeydown=e=>{if(e.key==="Enter")send()};

// ---------- profile ----------
function renderMe(){$("p-av").innerHTML=av(me);$("p-name").value=me.displayName;$("p-id").value=me.hafizId}
async function saveProfile(p){
  busy(true);
  try{await updateDoc(doc(db,"users",me.uid),p);Object.assign(me,p);renderMe();toast("Saved")}
  catch(e){toast("Not saved. "+errMsg(e))}
  busy(false);
}
$("p-save").onclick=()=>{const n=$("p-name").value.trim();n?saveProfile({displayName:n}):toast("Display name can't be empty.")};
$("p-copy").onclick=()=>navigator.clipboard.writeText(me.hafizId).then(()=>toast("ID copied"),()=>toast("Couldn't copy. Select the ID and copy it manually."));
$("p-out").onclick=()=>signOut(auth);
$("p-file").onchange=e=>{
  const f=e.target.files[0];if(!f)return;
  const img=new Image();
  img.onload=()=>{
    const c=document.createElement("canvas");c.width=c.height=128;
    const s=Math.min(img.width,img.height);
    c.getContext("2d").drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,128,128);
    URL.revokeObjectURL(img.src);
    saveProfile({photoURL:c.toDataURL("image/jpeg",.7)});
  };
  img.onerror=()=>toast("Couldn't read that image.");
  img.src=URL.createObjectURL(f);e.target.value="";
};
