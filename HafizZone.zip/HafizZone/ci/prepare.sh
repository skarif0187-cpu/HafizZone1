#!/bin/sh
# Runs inside the GitHub build after "npx cap add android": icons + Android permissions.
set -e
cd "$(dirname "$0")/.."
cp -r resources/res/. android/app/src/main/res/
M=android/app/src/main/AndroidManifest.xml
for p in POST_NOTIFICATIONS RECORD_AUDIO MODIFY_AUDIO_SETTINGS CAMERA; do
  sed -i "s#<application#<uses-permission android:name=\"android.permission.$p\" />\n    <application#" "$M"
done
grep -c "uses-permission" "$M"
