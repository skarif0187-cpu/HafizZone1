#!/bin/sh
# Runs inside the GitHub build after "npx cap add android": icons + Android permissions.
set -e
cd "$(dirname "$0")/.."
cp -r resources/res/. android/app/src/main/res/
M=android/app/src/main/AndroidManifest.xml
for p in POST_NOTIFICATIONS RECORD_AUDIO MODIFY_AUDIO_SETTINGS CAMERA; do
  sed -i "s#<application#<uses-permission android:name=\"android.permission.$p\" />\n    <application#" "$M"
done
grep -c "uses-permission" "$M"

# Always sign the debug APK with ~/.android/debug.keystore (the permanent key) when it exists
cat >> android/app/build.gradle <<'GRADLE'

android {
    signingConfigs {
        debug {
            def ks = file(System.getProperty("user.home") + "/.android/debug.keystore")
            if (ks.exists()) {
                storeFile ks
                storePassword "android"
                keyAlias "androiddebugkey"
                keyPassword "android"
            }
        }
    }
}
tasks.whenTaskAdded { t ->
    if (t.name == "packageDebug") {
        t.doLast {
            exec { commandLine "keytool", "-list", "-v", "-keystore", System.getProperty("user.home") + "/.android/debug.keystore", "-storepass", "android" }
        }
    }
}
GRADLE
