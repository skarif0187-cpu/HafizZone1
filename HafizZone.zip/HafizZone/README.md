# HafizZone

Simple chat app: HTML/CSS/JS + Firebase (Auth + Firestore, free Spark plan), packaged to APK with Capacitor.

## Files
- `www/index.html`, `style.css`, `app.js` – the whole app
- `www/firebase-config.js` – YOUR Firebase keys go here
- `firestore.rules` – security rules
- `package.json`, `capacitor.config.json` – Android wrapper

## 1. Firebase setup (free)
1. https://console.firebase.google.com > Add project (Analytics not needed).
2. Project overview > `</>` Web icon > register app "HafizZone" > copy the `firebaseConfig` values into `www/firebase-config.js`.
3. Build > Authentication > Get started > Sign-in method > enable **Email/Password**.
4. Build > Firestore Database > Create database > Production mode > pick a region.
5. Firestore > **Rules** tab > paste all of `firestore.rules` > Publish.
(No Storage needed. Profile pictures are small 128px images saved in Firestore.)

## 2. Test in browser
Needs a local server (not file://). In `www/`: `python -m http.server 8000` (or `npx serve www`), open http://localhost:8000.
Register two accounts (use a second browser or incognito window), search each other's ID, chat.

## 3. Build the APK
Install Node.js 18+, Android Studio (free), then in the project folder:
```
npm install
npx cap add android
npx cap sync
npx cap open android
```
In Android Studio wait for Gradle, then **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
APK: `android/app/build/outputs/apk/debug/app-debug.apk` – send it to friends (they must allow "install unknown apps").
After editing files in `www/`, run `npx cap sync` and rebuild.

## Notes
- The app needs internet. Never put service-account keys in the app; the web config is safe to include.
- Emails are never stored in Firestore, so other users can't see them.
